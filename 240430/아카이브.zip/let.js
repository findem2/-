// 변수 num을 선언한다
let num;

// 변수 num에 숫자 1을 할당한다
num = 1;

// 변수 num1에 3을 초기화 한다
let num1 = 3;

