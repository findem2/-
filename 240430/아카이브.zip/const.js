// 상수 num을 2로 초기화 한다
const num = 2;